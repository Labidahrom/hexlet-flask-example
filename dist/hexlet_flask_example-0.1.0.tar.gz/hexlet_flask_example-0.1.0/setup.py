# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['hexlet_flask_example']

package_data = \
{'': ['*'], 'hexlet_flask_example': ['templates/*', 'templates/users/*']}

install_requires = \
['flask>=2.2.2,<3.0.0', 'gunicorn>=20.1.0,<21.0.0']

entry_points = \
{'console_scripts': ['start_server = hexlet-flask.example:main']}

setup_kwargs = {
    'name': 'hexlet-flask-example',
    'version': '0.1.0',
    'description': '',
    'long_description': '# Brain Games\n### Hexlet tests and linter status:\n[![Actions Status](https://github.com/Labidahrom/python-project-lvl1/workflows/hexlet-check/badge.svg)](https://github.com/Labidahrom/python-project-lvl1/actions)\n<a href="https://codeclimate.com/github/Labidahrom/python-project-lvl1/maintainability"><img src="https://api.codeclimate.com/v1/badges/832ff76df613c8fcd2f3/maintainability" /></a>\n## Project description\nThis project contains several games with arithmetic questions. During the game user receives questions. If the user gave 3 correct answers in a row, the game ends successfully, but if at least 1 question was answered incorrectly during the game, the game ends with a loss.\n\n## System requirements\n- Linux\n- Python (3.6 or later)\n- PIP\n- Poetry\n- GIT\n\n## Installation\nOpen your terminal and type:\n```\ngit clone https://github.com/Labidahrom/python-project-lvl1\ncd python-project-lvl1\nmake package-install\n```\nAfter installation, all games will be available for launch from the terminal by commands:\n```\nbrain-even\nbrain-calc\nbrain-progression\nbrain-gcd\nbrain-prime\n```\n\n## How to play\n### Brain-even (Installation and gameplay)\n[![asciicast](https://asciinema.org/a/NS3VNS6usvyDogHkE7HJB4SPM.svg)](https://asciinema.org/a/NS3VNS6usvyDogHkE7HJB4SPM)\n### Brain-calc (Installation and gameplay)\n[![asciicast](https://asciinema.org/a/I50S9Ov5ETORbqQt68tCdzD85.svg)](https://asciinema.org/a/I50S9Ov5ETORbqQt68tCdzD85)\n### Brain-progression (Installation and gameplay)\n[![asciicast](https://asciinema.org/a/cHI7K31WamkC1mwHIGIJdaVJd.svg)](https://asciinema.org/a/cHI7K31WamkC1mwHIGIJdaVJd)\n### Brain-gcd (Installation and gameplay)\n[![asciicast](https://asciinema.org/a/k71aed8Yld8XYxGb2C7vdI9V5.svg)](https://asciinema.org/a/k71aed8Yld8XYxGb2C7vdI9V5)\n### Brain-prime (Installation and gameplay)\n[![asciicast](https://asciinema.org/a/2PAlx12UFxC9EgZMMUaoqjZTT.svg)](https://asciinema.org/a/2PAlx12UFxC9EgZMMUaoqjZTT)\n',
    'author': 'Labidahrom',
    'author_email': 'labidahrom@yandex.ru',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
